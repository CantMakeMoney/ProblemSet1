import java.util.Scanner;
/*
Description: This program tells the user the day of the week for any date input.
<CSC111-L>
@author: Josh Reynolds
 */
public class DayOfTheWeekCalculator {
    public static void main(String[] args) {
        Scanner scnr = new Scanner(System.in);
        String date;
        String day, month, year;
        int d, m, y;

        System.out.println("Day of the Week Calculator ===========================");
        System.out.println("0 -> Sunday\n1 -> Monday\n2 -> Tuesday\n3 -> Wednesday\n4 -> Thursday\n5 -> Friday\n6 -> Saturday");
        System.out.print("\nEnter a date in the following format [day-month-year e.g. 5-10-1999]: ");
        date = scnr.next();

        day = date.substring(0, date.indexOf("-"));
        month = date.substring(date.indexOf("-") + 1, date.indexOf("-", date.indexOf("-") + 1));
        year = date.substring(date.indexOf("-", date.indexOf("-") + 1) + 1, date.length());

        d = Integer.parseInt(day);
        m = Integer.parseInt(month);
        y = Integer.parseInt(year);

        int y0 = y - (14 - m) / 12;
        int x = y0 + y0/4 - y0/100 + y0/400;
        int m0 = m + 12 * ((14 - m)/12) - 2;
        int d0 = (d + x + (31 * m0)/12)%7;

        System.out.print("\nThe day of the week is " + d0);
    }
}
