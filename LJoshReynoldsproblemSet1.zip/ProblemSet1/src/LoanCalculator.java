import java.util.Scanner;
/*
 Description: This program takes a user's loan amount, annual interest rate, and term of loan (in years) as input
 and computes the monthly payment required to pay off the loan as well as the total interest that will be paid over
 the course of the loan.
 <CSC111-L>
 @author: Josh Reynolds
 */
public class LoanCalculator {
    public static void main(String[] args) {
        Scanner scnr = new Scanner(System.in);
        double principalAmount, monthlyPayment, rate,  totalInterest;
        int annualRate, years, n;

        System.out.println("Monthly Payment Calculator ===========================");
        System.out.print("Please enter the loan amount [e.g. 10000.00]: ");
        principalAmount = scnr.nextDouble();
        System.out.print("Please enter the annual interest rate [e.g. 5]: ");
        annualRate = scnr.nextInt();
        System.out.print("Please enter the term of the loan in years [e.g. 6]: ");
        years = scnr.nextInt();

        n = years * 12;
        rate = (annualRate / 100.0) / 12.0;
        monthlyPayment = principalAmount * (rate * Math.pow(1.0 + rate, n)) / (Math.pow(1.0 + rate, n) - 1.0);

        System.out.printf("\nMonthly payment: $%.2f", monthlyPayment);

        totalInterest = monthlyPayment * 12 * years - principalAmount;

        System.out.printf("\nTotal interest paid: $%.2f", totalInterest);
    }
}
