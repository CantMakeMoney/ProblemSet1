import java.util.Scanner;
/*
 Description: This program tells the user how many tanks of gas will need to be purchased along with the total cost of gas
 and the division of gas payments amongst the passengers based on the length of the trip in miles, miles per gallon, and gas price.
 <CSC111-L>
 @author: Josh Reynolds
 */
public class TripPlanner {
    public static void main(String[] args) {
        Scanner scnr = new Scanner(System.in);
        int numPassenger, tripLength, fuelCap, mpg;
        double gasPrice, numTank, numTankRounded, totalCost, pricePerPassenger;

        System.out.println("My Trip Planner ===========================");
        System.out.print("Number of passengers: ");
        numPassenger = scnr.nextInt();
        System.out.print("Length of the trip in miles: ");
        tripLength = scnr.nextInt();
        System.out.print("Capacity of the car's gas tank in gallons: ");
        fuelCap = scnr.nextInt();
        System.out.print("Price of one gallon of gas: ");
        gasPrice = scnr.nextDouble();
        System.out.print("Miles/gallon of your car: ");
        mpg = scnr.nextInt();

        numTank = (1.0 / fuelCap) * (1.0 / mpg) * tripLength;
        numTankRounded = Math.ceil(numTank);
        totalCost = numTankRounded * fuelCap * gasPrice;
        pricePerPassenger = numTankRounded * gasPrice * fuelCap / numPassenger;

        System.out.printf("\n\nYou will need up to %.0f", numTankRounded);
        System.out.printf(" tanks of gas\nThe total cost will be %.2f", totalCost);
        System.out.printf(" dollars\nEach passenger should pay %.2f", pricePerPassenger);
        System.out.print(" dollars");
    }
}
