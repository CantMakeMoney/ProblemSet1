import java.util.Scanner;
/*
 Description: This program estimates a user's carbon footprint based on their daily eating habits.
 A carbon footprint is the concentration of carbon dioxide that a person, event, or organization emits.
 The carbon footprint is expressed in units of carbon dioxide equivalence (CO2e).
 <CSC111-L>
 @author: Josh Reynolds
 */
public class FoodCarbonFootprint {
    public static void main(String[] args) {
        Scanner scnr = new Scanner(System.in);
        int beef, chicken, cheese, yogurt, milk, eggs, tofu, beans, lentils, nuts;
        double kgCO2e, annualTonsCO2e;

        System.out.println("Food Carbon Footprint Calculator ===========================" + "\n");
        System.out.println("Please enter the amount of kilocalories you consume for these food types.");

        System.out.print("Beef: ");
        beef = scnr.nextInt();
        System.out.print("Chicken: ");
        chicken = scnr.nextInt();
        System.out.print("Cheese: ");
        cheese = scnr.nextInt();
        System.out.print("Yogurt: ");
        yogurt = scnr.nextInt();
        System.out.print("Milk: ");
        milk = scnr.nextInt();
        System.out.print("Eggs: ");
        eggs = scnr.nextInt();
        System.out.print("Tofu: ");
        tofu = scnr.nextInt();
        System.out.print("Beans: ");
        beans = scnr.nextInt();
        System.out.print("Lentils: ");
        lentils = scnr.nextInt();
        System.out.print("Nuts: ");
        nuts = scnr.nextInt();

        kgCO2e = (0.01378*beef + 0.00337*chicken + 0.00447*cheese + 0.00349*yogurt + 0.00317*milk + 0.00306*eggs + 0.00138*tofu + 0.00140*beans + 0.00078*lentils + 0.00039*nuts);
        annualTonsCO2e = (kgCO2e/907) * 365;

        System.out.println("\n" + "Your total number of kilocalories per day would be: " + (beef+chicken+cheese+yogurt+milk+eggs+tofu+beans+lentils+nuts));
        System.out.print("Your daily food carbon footprint would be ");
        System.out.printf("%.3f", kgCO2e);
        System.out.println(" kilograms of carbon dioxide equivalent.");
        System.out.print("Your annual food carbon footprint would be ");
        System.out.printf("%.3f", annualTonsCO2e);
        System.out.println(" tons of carbon dioxide equivalent.");

    }
}